// ─────────────────────────────────────────
//   DIVINE EXCHANGE — LOGGER UTILITY
// ─────────────────────────────────────────
const config = require('../config');
const emojis = require('../emojis');

/**
 * Send a log embed to the appropriate log channel
 * @param {Client} client
 * @param {'log'|'exchangerLog'|'taxLog'} channelKey
 * @param {Object} embedData
 */
async function sendLog(client, channelKey, embedData) {
  try {
    const channelId = config.channels[channelKey];
    if (!channelId) return;
    const channel = await client.channels.fetch(channelId);
    if (!channel) return;
    await channel.send({ embeds: [embedData] });
  } catch (e) {
    console.error(`[Logger] Failed to log to ${channelKey}:`, e.message);
  }
}

async function logDealOpened(client, { dealId, userId, exchangerId, type, amount, usdtValue }) {
  await sendLog(client, 'log', {
    color: 0x3498db,
    title: `${emojis.deal} New Deal Opened`,
    fields: [
      { name: 'Deal ID',    value: `\`${dealId}\``,         inline: true },
      { name: 'Type',       value: type,                     inline: true },
      { name: 'Amount',     value: `$${usdtValue} USDT`,     inline: true },
      { name: 'Client',     value: `<@${userId}>`,           inline: true },
      { name: 'Exchanger',  value: `<@${exchangerId}>`,      inline: true },
    ],
    timestamp: new Date().toISOString(),
    footer: { text: 'Divine Exchange • Deal Log' },
  });
}

async function logDealCompleted(client, { dealId, userId, exchangerId, amount, fee }) {
  await sendLog(client, 'log', {
    color: 0x2ecc71,
    title: `${emojis.complete} Deal Completed`,
    fields: [
      { name: 'Deal ID',   value: `\`${dealId}\``,       inline: true },
      { name: 'Amount',    value: `$${amount} USDT`,      inline: true },
      { name: 'Fee Due',   value: `$${fee} USDT (${config.dealFeePercent}%)`, inline: true },
      { name: 'Client',    value: `<@${userId}>`,         inline: true },
      { name: 'Exchanger', value: `<@${exchangerId}>`,    inline: true },
    ],
    timestamp: new Date().toISOString(),
    footer: { text: 'Divine Exchange • Deal Log' },
  });
}

async function logDealDisputed(client, { dealId, userId, exchangerId, reason }) {
  await sendLog(client, 'log', {
    color: 0xe74c3c,
    title: `${emojis.disputed} Deal Disputed`,
    fields: [
      { name: 'Deal ID',   value: `\`${dealId}\``,    inline: true },
      { name: 'Client',    value: `<@${userId}>`,      inline: true },
      { name: 'Exchanger', value: `<@${exchangerId}>`, inline: true },
      { name: 'Reason',    value: reason || 'No reason provided', inline: false },
    ],
    timestamp: new Date().toISOString(),
    footer: { text: 'Divine Exchange • Dispute Log' },
  });
}

async function logExchangerApproved(client, { userId, collateral, dealLimit }) {
  await sendLog(client, 'exchangerLog', {
    color: 0x2ecc71,
    title: `${emojis.verified} Exchanger Approved`,
    fields: [
      { name: 'User',       value: `<@${userId}>`,        inline: true },
      { name: 'Collateral', value: `$${collateral} USDT`, inline: true },
      { name: 'Deal Limit', value: `$${dealLimit} USDT`,  inline: true },
    ],
    timestamp: new Date().toISOString(),
    footer: { text: 'Divine Exchange • Exchanger Log' },
  });
}

async function logTaxPaid(client, { userId, amount, dealId, txHash }) {
  await sendLog(client, 'taxLog', {
    color: 0xf39c12,
    title: `${emojis.paid} Tax Payment Claimed`,
    description: `${emojis.info} Admin must verify and remove Tax Due restriction.`,
    fields: [
      { name: 'Exchanger', value: `<@${userId}>`,           inline: true },
      { name: 'Amount',    value: `$${amount} USDT`,        inline: true },
      { name: 'Deal ID',   value: `\`${dealId}\``,          inline: true },
      { name: 'TX Hash',   value: txHash || 'Not provided', inline: false },
    ],
    timestamp: new Date().toISOString(),
    footer: { text: 'Divine Exchange • Tax Log' },
  });
}

async function logExchangerLeft(client, { userId }) {
  await sendLog(client, 'exchangerLog', {
    color: 0x95a5a6,
    title: `${emojis.cancel} Exchanger Left Server`,
    description: `<@${userId}> has left. Their recovery token has been revoked.`,
    timestamp: new Date().toISOString(),
    footer: { text: 'Divine Exchange • Exchanger Log' },
  });
}

module.exports = {
  logDealOpened, logDealCompleted, logDealDisputed,
  logExchangerApproved, logTaxPaid, logExchangerLeft,
};

// ─────────────────────────────────────────
//   DIVINE EXCHANGE — RECOVERY TOKEN UTIL
// ─────────────────────────────────────────
const crypto = require('crypto');
const db     = require('./db');

/**
 * Generate a secure recovery token for an exchanger
 * Stored in DB and DM'd to them on approval
 */
function generateToken() {
  return 'DE-' + crypto.randomBytes(16).toString('hex').toUpperCase();
}

async function issueRecoveryToken(userId, client) {
  const token = generateToken();
  db.setRecoveryToken(userId, {
    token,
    userId,
    issuedAt: Date.now(),
    revoked: false,
    revokedAt: null,
    usedBy: null,
  });

  // DM the exchanger their token
  try {
    const user = await client.users.fetch(userId);
    const emojis = require('../emojis');
    await user.send({
      embeds: [{
        color: 0x2ecc71,
        title: `${emojis.token} Your Recovery Token`,
        description:
          `> Keep this token **safe and private**. It can be used to restore your Exchanger role if you lose access to your account.\n\n` +
          `**Token:**\n\`\`\`\n${token}\n\`\`\`\n` +
          `${emojis.warning} **Never share this with anyone — not even admins.**\n` +
          `${emojis.info} This token is tied to your Exchanger account and will be revoked if you leave the server.`,
        footer: { text: 'Divine Exchange • Recovery System' },
        timestamp: new Date().toISOString(),
      }]
    });
  } catch (e) {
    console.error('[Recovery] Could not DM token to user:', e.message);
  }

  return token;
}

/**
 * Validate and use a recovery token on a new account
 */
async function useRecoveryToken(newUserId, token, guild, config) {
  const entry = db.getRecoveryToken(token);
  if (!entry) return { success: false, reason: 'Invalid token.' };

  const [originalUserId, data] = entry;

  if (data.revoked)    return { success: false, reason: 'This token has been revoked.' };
  if (data.usedBy)     return { success: false, reason: 'This token has already been used.' };
  if (originalUserId === newUserId) return { success: false, reason: 'You cannot use your own token on the same account.' };

  // Get original exchanger data
  const exchangerData = db.getExchanger(originalUserId);
  if (!exchangerData) return { success: false, reason: 'No exchanger data found for this token.' };

  // Transfer exchanger data to new account
  db.setExchanger(newUserId, {
    ...exchangerData,
    userId: newUserId,
    originalUserId,
    recoveredAt: Date.now(),
    activeDeal: null, // reset active deal
  });

  // Mark token as used
  const dbData = require('./db');
  dbData.setRecoveryToken(originalUserId, {
    ...data,
    usedBy: newUserId,
    usedAt: Date.now(),
  });

  // Issue new token for new account
  await issueRecoveryToken(newUserId, guild.client);

  // Assign exchanger role
  try {
    const member = await guild.members.fetch(newUserId);
    await member.roles.add(config.roles.exchanger);
    if (exchangerData.verified) {
      await member.roles.add(config.roles.verifiedExchanger);
    }
  } catch (e) {
    console.error('[Recovery] Role assignment failed:', e.message);
  }

  return { success: true, exchangerData };
}

/**
 * Revoke token when exchanger leaves
 */
function revokeToken(userId) {
  db.revokeRecoveryToken(userId);
}

module.exports = { issueRecoveryToken, useRecoveryToken, revokeToken };

// ─────────────────────────────────────────
//   DIVINE EXCHANGE — DATABASE (JSON)
//   Simple file-based storage
// ─────────────────────────────────────────
const fs   = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../../data/db.json');

function load() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = { exchangers: {}, tickets: {}, deals: {}, taxes: {}, recoveryTokens: {} };
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}

function save(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// ── Exchanger ────────────────────────────

function getExchanger(userId) {
  const db = load();
  return db.exchangers[userId] || null;
}

function setExchanger(userId, data) {
  const db = load();
  db.exchangers[userId] = { ...db.exchangers[userId], ...data };
  save(db);
}

function getAllExchangers() {
  return load().exchangers;
}

// ── Tickets ──────────────────────────────

function getTicket(channelId) {
  const db = load();
  return db.tickets[channelId] || null;
}

function setTicket(channelId, data) {
  const db = load();
  db.tickets[channelId] = { ...db.tickets[channelId], ...data };
  save(db);
}

function getTicketByUser(userId) {
  const db = load();
  return Object.entries(db.tickets).find(([, t]) => t.userId === userId && t.status === 'open') || null;
}

function getAllTickets() {
  return load().tickets;
}

// ── Deals ────────────────────────────────

function getDeal(dealId) {
  const db = load();
  return db.deals[dealId] || null;
}

function setDeal(dealId, data) {
  const db = load();
  db.deals[dealId] = { ...db.deals[dealId], ...data };
  save(db);
}

function getActiveDealByExchanger(exchangerId) {
  const db = load();
  return Object.entries(db.deals).find(([, d]) => d.exchangerId === exchangerId && d.status === 'active') || null;
}

function getAllDeals() {
  return load().deals;
}

// ── Taxes ────────────────────────────────

function getTax(userId) {
  const db = load();
  return db.taxes[userId] || null;
}

function setTax(userId, data) {
  const db = load();
  db.taxes[userId] = { ...db.taxes[userId], ...data };
  save(db);
}

function getTotalPendingTax(userId) {
  const db = load();
  const taxes = db.taxes[userId];
  if (!taxes || !taxes.pending) return 0;
  return taxes.pending.reduce((sum, t) => sum + t.amount, 0);
}

// ── Recovery Tokens ──────────────────────

function getRecoveryToken(token) {
  const db = load();
  return Object.entries(db.recoveryTokens).find(([, t]) => t.token === token) || null;
}

function setRecoveryToken(userId, data) {
  const db = load();
  db.recoveryTokens[userId] = data;
  save(db);
}

function revokeRecoveryToken(userId) {
  const db = load();
  if (db.recoveryTokens[userId]) {
    db.recoveryTokens[userId].revoked = true;
    db.recoveryTokens[userId].revokedAt = Date.now();
    save(db);
  }
}

function getRecoveryByUserId(userId) {
  const db = load();
  return db.recoveryTokens[userId] || null;
}

module.exports = {
  getExchanger, setExchanger, getAllExchangers,
  getTicket, setTicket, getTicketByUser, getAllTickets,
  getDeal, setDeal, getActiveDealByExchanger, getAllDeals,
  getTax, setTax, getTotalPendingTax,
  getRecoveryToken, setRecoveryToken, revokeRecoveryToken, getRecoveryByUserId,
};

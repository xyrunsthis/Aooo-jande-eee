// ─────────────────────────────────────────
//   DIVINE EXCHANGE — RATES UTILITY
//   Fetches USDT/INR and crypto rates
//   via CoinGecko (free, no API key)
// ─────────────────────────────────────────
const https = require('https');

let cache = {
  usdtInr: null,
  btcUsdt: null,
  ethUsdt: null,
  updatedAt: null,
};

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'DivineExchange/1.0' } }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(e); }
      });
    }).on('error', reject);
  });
}

async function refreshRates() {
  try {
    const data = await fetchJSON(
      'https://api.coingecko.com/api/v3/simple/price?ids=tether,bitcoin,ethereum&vs_currencies=inr,usd'
    );
    cache.usdtInr  = data?.tether?.inr   || null;
    cache.btcUsdt  = data?.bitcoin?.usd  || null;
    cache.ethUsdt  = data?.ethereum?.usd || null;
    cache.updatedAt = Date.now();
    return cache;
  } catch (e) {
    console.error('[Rates] Failed to fetch:', e.message);
    return cache;
  }
}

async function getRates() {
  const config = require('../config');
  const stale = !cache.updatedAt || (Date.now() - cache.updatedAt) > config.ratesRefreshMinutes * 60 * 1000;
  if (stale) await refreshRates();
  return cache;
}

// Convert USDT amount to INR
async function usdtToInr(usdt) {
  const rates = await getRates();
  if (!rates.usdtInr) return null;
  return (usdt * rates.usdtInr).toFixed(2);
}

// Convert INR amount to USDT
async function inrToUsdt(inr) {
  const rates = await getRates();
  if (!rates.usdtInr) return null;
  return (inr / rates.usdtInr).toFixed(4);
}

module.exports = { getRates, refreshRates, usdtToInr, inrToUsdt };

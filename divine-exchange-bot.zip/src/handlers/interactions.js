// ─────────────────────────────────────────
//   DIVINE EXCHANGE — INTERACTION HANDLER
//   Handles buttons, select menus, modals
// ─────────────────────────────────────────
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ModalBuilder, TextInputBuilder, TextInputStyle,
  EmbedBuilder, PermissionFlagsBits, ChannelType
} = require('discord.js');
const config   = require('../config');
const emojis   = require('../emojis');
const db       = require('../utils/db');
const logger   = require('../utils/logger');
const recovery = require('../utils/recovery');
const { getRates, usdtToInr, inrToUsdt } = require('../utils/rates');

module.exports = async (interaction) => {
  // ── Buttons ────────────────────────────
  if (interaction.isButton()) {
    if (interaction.customId === 'start_exchange')    return handleStartExchange(interaction);
    if (interaction.customId === 'view_rates')        return handleViewRates(interaction);
    if (interaction.customId === 'restore_roles')     return handleRestoreRoles(interaction);
    if (interaction.customId.startsWith('claim_deal_'))    return handleClaimDeal(interaction);
    if (interaction.customId.startsWith('confirm_deal_'))  return handleConfirmDeal(interaction);
    if (interaction.customId.startsWith('dispute_deal_'))  return handleDisputeDeal(interaction);
    if (interaction.customId.startsWith('close_ticket_'))  return handleCloseTicket(interaction);
    if (interaction.customId.startsWith('tax_paid_'))      return handleTaxPaid(interaction);
  }

  // ── Select Menus ───────────────────────
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId === 'support_ticket_select') return handleSupportTicket(interaction);
    if (interaction.customId === 'exchange_type_select')  return handleExchangeType(interaction);
  }

  // ── Modals ─────────────────────────────
  if (interaction.isModalSubmit()) {
    if (interaction.customId === 'exchange_modal')    return handleExchangeModal(interaction);
    if (interaction.customId === 'recovery_modal')    return handleRecoveryModal(interaction);
    if (interaction.customId.startsWith('dispute_modal_')) return handleDisputeModal(interaction);
    if (interaction.customId.startsWith('tax_modal_'))     return handleTaxModal(interaction);
  }
};

// ── Start Exchange Button ───────────────

async function handleStartExchange(interaction) {
  const { StringSelectMenuBuilder } = require('discord.js');

  // Check if user already has an open ticket
  const existing = db.getTicketByUser(interaction.user.id);
  if (existing) {
    return interaction.reply({
      content: `${emojis.error} You already have an open exchange ticket: <#${existing[0]}>`,
      ephemeral: true
    });
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId('exchange_type_select')
    .setPlaceholder('Select exchange type...')
    .addOptions([
      { label: 'Crypto → INR',    description: 'Send USDT, receive INR via UPI',    value: 'crypto_to_inr',    emoji: '💸' },
      { label: 'INR → Crypto',    description: 'Send INR via UPI, receive USDT',    value: 'inr_to_crypto',    emoji: '💰' },
      { label: 'Crypto → Crypto', description: 'Exchange between cryptocurrencies', value: 'crypto_to_crypto',  emoji: '🔄' },
    ]);

  const row = new ActionRowBuilder().addComponents(menu);

  await interaction.reply({
    content: `${emojis.exchange} **Select your exchange type:**`,
    components: [row],
    ephemeral: true
  });
}

// ── Exchange Type Selected ──────────────

async function handleExchangeType(interaction) {
  const type = interaction.values[0];

  const typeLabels = {
    crypto_to_inr:    'Crypto → INR',
    inr_to_crypto:    'INR → Crypto',
    crypto_to_crypto: 'Crypto → Crypto',
  };

  const modal = new ModalBuilder()
    .setCustomId('exchange_modal')
    .setTitle(`${typeLabels[type]} Exchange`);

  const amountInput = new TextInputBuilder()
    .setCustomId('amount')
    .setLabel('Amount (in USDT)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('e.g. 50')
    .setRequired(true);

  const fromInput = new TextInputBuilder()
    .setCustomId('exchange_type')
    .setLabel('Exchange Type (do not change)')
    .setStyle(TextInputStyle.Short)
    .setValue(type)
    .setRequired(true);

  const upiInput = new TextInputBuilder()
    .setCustomId('upi_id')
    .setLabel(type === 'inr_to_crypto' ? 'Your UPI ID' : type === 'crypto_to_inr' ? 'Recipient UPI ID' : 'Your USDT Wallet (Polygon)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(type.includes('inr') ? 'example@upi' : '0x...')
    .setRequired(true);

  const notesInput = new TextInputBuilder()
    .setCustomId('notes')
    .setLabel('Additional Notes (optional)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(amountInput),
    new ActionRowBuilder().addComponents(fromInput),
    new ActionRowBuilder().addComponents(upiInput),
    new ActionRowBuilder().addComponents(notesInput),
  );

  await interaction.showModal(modal);
}

// ── Exchange Modal Submit ───────────────

async function handleExchangeModal(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const amount       = parseFloat(interaction.fields.getTextInputValue('amount'));
  const exchangeType = interaction.fields.getTextInputValue('exchange_type');
  const upiOrWallet  = interaction.fields.getTextInputValue('upi_id');
  const notes        = interaction.fields.getTextInputValue('notes') || 'None';

  if (isNaN(amount) || amount <= 0) {
    return interaction.editReply(`${emojis.error} Invalid amount.`);
  }

  const rates = await getRates();
  const inrEquiv = rates.usdtInr ? `₹${(amount * rates.usdtInr).toFixed(2)}` : 'N/A';

  const typeLabels = {
    crypto_to_inr:    'Crypto → INR',
    inr_to_crypto:    'INR → Crypto',
    crypto_to_crypto: 'Crypto → Crypto',
  };

  // Find available exchanger (first available, not on active deal, limit >= amount)
  const allExchangers = db.getAllExchangers();
  const available = Object.values(allExchangers).filter(e =>
    e.status === 'active' &&
    !e.activeDeal &&
    !e.taxDue &&
    e.dealLimit >= amount
  );

  // Create the ticket channel
  const guild    = interaction.guild;
  const ticketId = `exchange-${interaction.user.id.slice(-4)}-${Date.now().toString().slice(-4)}`;

  let channel;
  try {
    channel = await guild.channels.create({
      name: ticketId,
      type: ChannelType.GuildText,
      parent: config.categories.exchangeTicket,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id,     allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        { id: config.roles.admin,      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        { id: config.roles.exchanger,  allow: [PermissionFlagsBits.ViewChannel] }, // can see but claim to join
      ],
    });
  } catch (e) {
    return interaction.editReply(`${emojis.error} Failed to create ticket channel. Check bot permissions.`);
  }

  // Save ticket to DB
  const dealId = `DEAL-${Date.now()}`;
  db.setTicket(channel.id, {
    channelId: channel.id,
    userId: interaction.user.id,
    dealId,
    exchangeType,
    amount,
    inrEquiv,
    upiOrWallet,
    notes,
    status: 'open',
    exchangerId: null,
    createdAt: Date.now(),
  });

  // Build the ticket embed
  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`${emojis.ticket} Exchange Request`)
    .addFields(
      { name: `${emojis.exchange} Type`,     value: typeLabels[exchangeType],       inline: true },
      { name: `${emojis.usdt} Amount`,       value: `$${amount} USDT`,              inline: true },
      { name: `${emojis.inr} INR Equiv.`,    value: inrEquiv,                       inline: true },
      { name: `${emojis.upi} UPI / Wallet`,  value: `\`${upiOrWallet}\``,           inline: false },
      { name: `${emojis.info} Notes`,        value: notes,                          inline: false },
      { name: `${emojis.pending} Status`,    value: 'Waiting for Exchanger to claim', inline: true },
    )
    .setFooter({ text: `${config.botName} • Deal ID: ${dealId}` })
    .setTimestamp();

  const claimRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`claim_deal_${channel.id}`)
      .setLabel('Claim This Deal')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`close_ticket_${channel.id}`)
      .setLabel('Cancel')
      .setStyle(ButtonStyle.Danger),
  );

  await channel.send({
    content: `<@${interaction.user.id}> ${emojis.rocket} Your exchange ticket has been opened! An exchanger will claim it shortly.\n${config.roles.exchanger ? `<@&${config.roles.exchanger}>` : ''}`,
    embeds: [embed],
    components: [claimRow],
  });

  await interaction.editReply(`${emojis.success} Your exchange ticket has been created: ${channel}`);
}

// ── Claim Deal ──────────────────────────

async function handleClaimDeal(interaction) {
  const channelId    = interaction.customId.replace('claim_deal_', '');
  const ticket       = db.getTicket(channelId);
  const exchangerData = db.getExchanger(interaction.user.id);

  if (!ticket)        return interaction.reply({ content: `${emojis.error} Ticket not found.`, ephemeral: true });
  if (ticket.exchangerId) return interaction.reply({ content: `${emojis.error} This deal has already been claimed.`, ephemeral: true });
  if (!exchangerData) return interaction.reply({ content: `${emojis.error} You are not a registered exchanger.`, ephemeral: true });
  if (exchangerData.status !== 'active') return interaction.reply({ content: `${emojis.error} Your exchanger account is not active.`, ephemeral: true });
  if (exchangerData.taxDue) return interaction.reply({ content: `${emojis.error} You have pending tax dues. Pay your taxes first before claiming deals.`, ephemeral: true });
  if (exchangerData.activeDeal) return interaction.reply({ content: `${emojis.error} You already have an active deal. Complete it first.`, ephemeral: true });
  if (exchangerData.dealLimit < ticket.amount) return interaction.reply({ content: `${emojis.error} This deal ($${ticket.amount}) exceeds your deal limit ($${exchangerData.dealLimit}).`, ephemeral: true });
  if (ticket.userId === interaction.user.id) return interaction.reply({ content: `${emojis.error} You cannot claim your own exchange ticket.`, ephemeral: true });

  // Assign exchanger to ticket
  db.setTicket(channelId, { exchangerId: interaction.user.id, status: 'active', claimedAt: Date.now() });
  db.setExchanger(interaction.user.id, { activeDeal: ticket.dealId });
  db.setDeal(ticket.dealId, {
    dealId:      ticket.dealId,
    channelId,
    userId:      ticket.userId,
    exchangerId: interaction.user.id,
    amount:      ticket.amount,
    exchangeType: ticket.exchangeType,
    status:      'active',
    createdAt:   ticket.createdAt,
    claimedAt:   Date.now(),
  });

  // Give exchanger view + send permissions
  await interaction.channel.permissionOverwrites.edit(interaction.user.id, {
    ViewChannel:  true,
    SendMessages: true,
  });

  await logger.logDealOpened(interaction.client, {
    dealId:      ticket.dealId,
    userId:      ticket.userId,
    exchangerId: interaction.user.id,
    type:        ticket.exchangeType,
    amount:      ticket.amount,
    usdtValue:   ticket.amount,
  });

  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle(`${emojis.active} Deal Claimed!`)
    .setDescription(
      `${emojis.exchanger} **Exchanger:** <@${interaction.user.id}>\n` +
      `${emojis.dot} Complete the exchange and both parties must confirm.\n` +
      `${emojis.dot} Client must send a **split-screen screenshot** showing UPI payment + Discord simultaneously.\n` +
      `${emojis.warning} Disputes will be reviewed by admins. Scammers lose their collateral.`
    )
    .setFooter({ text: `${config.botName} • Deal ID: ${ticket.dealId}` })
    .setTimestamp();

  const actionRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`confirm_deal_${channelId}`)
      .setLabel('Mark as Complete')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`dispute_deal_${channelId}`)
      .setLabel('Raise Dispute')
      .setStyle(ButtonStyle.Danger),
  );

  await interaction.update({ components: [] }); // remove claim button
  await interaction.channel.send({ embeds: [embed], components: [actionRow] });
}

// ── Confirm Deal ────────────────────────

async function handleConfirmDeal(interaction) {
  const channelId = interaction.customId.replace('confirm_deal_', '');
  const ticket    = db.getTicket(channelId);

  if (!ticket || ticket.status !== 'active') {
    return interaction.reply({ content: `${emojis.error} No active deal found.`, ephemeral: true });
  }

  const isClient    = interaction.user.id === ticket.userId;
  const isExchanger = interaction.user.id === ticket.exchangerId;
  if (!isClient && !isExchanger) {
    return interaction.reply({ content: `${emojis.error} Only the client or exchanger can confirm.`, ephemeral: true });
  }

  // Track confirmations
  const deal = db.getDeal(ticket.dealId);
  const confirmations = deal.confirmations || {};
  confirmations[interaction.user.id] = true;
  db.setDeal(ticket.dealId, { confirmations });

  const bothConfirmed = confirmations[ticket.userId] && confirmations[ticket.exchangerId];

  if (!bothConfirmed) {
    return interaction.reply({
      content: `${emojis.success} Your confirmation recorded! Waiting for ${isClient ? 'exchanger' : 'client'} to confirm.`,
      ephemeral: true
    });
  }

  // Both confirmed — complete the deal
  const fee = parseFloat((ticket.amount * config.dealFeePercent / 100).toFixed(4));

  db.setTicket(channelId, { status: 'completed', completedAt: Date.now() });
  db.setDeal(ticket.dealId, { status: 'completed', fee, completedAt: Date.now() });

  // Update exchanger stats + add pending tax
  const exchData = db.getExchanger(ticket.exchangerId);
  db.setExchanger(ticket.exchangerId, {
    activeDeal:   null,
    totalDeals:   (exchData.totalDeals || 0) + 1,
    totalVolume:  (exchData.totalVolume || 0) + ticket.amount,
    pendingTax:   (exchData.pendingTax || 0) + fee,
    taxDue:       true,
  });

  // Add Tax Due role
  try {
    const member = await interaction.guild.members.fetch(ticket.exchangerId);
    await member.roles.add(config.roles.taxDue);
  } catch (_) {}

  await logger.logDealCompleted(interaction.client, {
    dealId:      ticket.dealId,
    userId:      ticket.userId,
    exchangerId: ticket.exchangerId,
    amount:      ticket.amount,
    fee,
  });

  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle(`${emojis.complete} Deal Completed!`)
    .setDescription(`Both parties have confirmed. The exchange is complete!`)
    .addFields(
      { name: `${emojis.usdt} Amount`,    value: `$${ticket.amount} USDT`, inline: true },
      { name: `${emojis.fee} Fee Due`,    value: `$${fee} USDT (${config.dealFeePercent}%)`, inline: true },
      { name: `${emojis.wallet} Pay Fee To`, value: `\`${config.ownerWallet}\`\n*(Polygon USDT)*`, inline: false },
      { name: `${emojis.warning} Tax Notice`, value: `<@${ticket.exchangerId}> — You now have a tax due of **$${fee} USDT**.\nSend it to the wallet above, then click **Tax Paid** below.`, inline: false },
    )
    .setFooter({ text: `${config.botName} • Deal ID: ${ticket.dealId}` })
    .setTimestamp();

  const taxRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`tax_paid_${channelId}`)
      .setLabel('Tax Paid')
      .setStyle(ButtonStyle.Primary),
  );

  await interaction.update({ components: [] });
  await interaction.channel.send({ embeds: [embed], components: [taxRow] });
}

// ── Dispute Deal ────────────────────────

async function handleDisputeDeal(interaction) {
  const channelId = interaction.customId.replace('dispute_deal_', '');

  const modal = new ModalBuilder()
    .setCustomId(`dispute_modal_${channelId}`)
    .setTitle('Raise a Dispute');

  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('reason')
        .setLabel('Describe the issue')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Explain what went wrong...')
        .setRequired(true)
    )
  );

  await interaction.showModal(modal);
}

async function handleDisputeModal(interaction) {
  const channelId = interaction.customId.replace('dispute_modal_', '');
  const reason    = interaction.fields.getTextInputValue('reason');
  const ticket    = db.getTicket(channelId);

  if (!ticket) return interaction.reply({ content: `${emojis.error} Ticket not found.`, ephemeral: true });

  db.setTicket(channelId, { status: 'disputed', disputeReason: reason, disputedAt: Date.now(), disputedBy: interaction.user.id });
  db.setDeal(ticket.dealId, { status: 'disputed' });

  await logger.logDealDisputed(interaction.client, {
    dealId:      ticket.dealId,
    userId:      ticket.userId,
    exchangerId: ticket.exchangerId,
    reason,
  });

  const embed = new EmbedBuilder()
    .setColor(0xe74c3c)
    .setTitle(`${emojis.disputed} Dispute Raised`)
    .setDescription(`An admin will review this dispute.\n\n**Reason:** ${reason}\n\n${emojis.warning} If the exchanger is found guilty, their collateral of **$${db.getExchanger(ticket.exchangerId)?.collateral || '?'} USDT** will be returned to the client.`)
    .addFields({ name: `${emojis.admin} Admins`, value: config.roles.admin ? `<@&${config.roles.admin}>` : 'Please contact an admin.' })
    .setFooter({ text: `${config.botName} • Deal ID: ${ticket.dealId}` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ── Tax Paid ────────────────────────────

async function handleTaxPaid(interaction) {
  const channelId    = interaction.customId.replace('tax_paid_', '');
  const ticket       = db.getTicket(channelId);
  const exchangerData = db.getExchanger(interaction.user.id);

  if (!ticket) return interaction.reply({ content: `${emojis.error} Ticket not found.`, ephemeral: true });
  if (interaction.user.id !== ticket.exchangerId) {
    return interaction.reply({ content: `${emojis.error} Only the exchanger can mark tax as paid.`, ephemeral: true });
  }

  const modal = new ModalBuilder()
    .setCustomId(`tax_modal_${channelId}`)
    .setTitle('Tax Payment Confirmation');

  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('tx_hash')
        .setLabel('Transaction Hash / Screenshot proof')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('0x... or describe your proof')
        .setRequired(true)
    )
  );

  await interaction.showModal(modal);
}

async function handleTaxModal(interaction) {
  const channelId = interaction.customId.replace('tax_modal_', '');
  const txHash    = interaction.fields.getTextInputValue('tx_hash');
  const ticket    = db.getTicket(channelId);
  const deal      = db.getDeal(ticket?.dealId);

  await logger.logTaxPaid(interaction.client, {
    userId:  interaction.user.id,
    amount:  deal?.fee || 0,
    dealId:  ticket?.dealId,
    txHash,
  });

  const embed = new EmbedBuilder()
    .setColor(0xf39c12)
    .setTitle(`${emojis.tax} Tax Payment Submitted`)
    .setDescription(`${emojis.info} An admin will verify your payment and remove the Tax Due restriction.\n\n**TX / Proof:** \`${txHash}\``)
    .addFields({ name: `${emojis.admin} Admins`, value: config.roles.admin ? `<@&${config.roles.admin}> — please verify and use \`/exchanger cleartax\` to clear.` : 'Admins, please verify.' })
    .setFooter({ text: `${config.botName} • Tax System` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ── View Rates ──────────────────────────

async function handleViewRates(interaction) {
  const rates    = await getRates();
  const usdtInr  = rates.usdtInr ? `₹${rates.usdtInr.toLocaleString('en-IN')}` : 'Unavailable';

  await interaction.reply({
    embeds: [{
      color: 0xf39c12,
      title: `${emojis.rates} Live Exchange Rates`,
      fields: [
        { name: `${emojis.usdt} 1 USDT`, value: `= ${usdtInr}`, inline: true },
        { name: `${emojis.fee} Fee`,      value: `${config.dealFeePercent}% per deal`, inline: true },
        { name: `${emojis.wallet} Network`, value: 'Polygon (USDT)', inline: true },
      ],
      footer: { text: `${config.botName} • Rates updated every ${config.ratesRefreshMinutes} min` },
      timestamp: new Date().toISOString(),
    }],
    ephemeral: true
  });
}

// ── Support Ticket Select ───────────────

async function handleSupportTicket(interaction) {
  const type   = interaction.values[0];
  const labels = {
    general:      'General Support',
    staff_app:    'Staff Application',
    exchanger_app:'Become an Exchanger',
    report:       'Report Issues',
    recovery:     'Account Recovery',
    partnership:  'Partnership Inquiries',
    rewards:      'Claim Rewards',
  };

  const existing = db.getTicketByUser(interaction.user.id);
  if (existing) {
    return interaction.reply({
      content: `${emojis.error} You already have an open ticket: <#${existing[0]}>`,
      ephemeral: true
    });
  }

  const guild   = interaction.guild;
  const ticketName = `${type.replace(/_/g,'-')}-${interaction.user.id.slice(-4)}`;

  let channel;
  try {
    channel = await guild.channels.create({
      name: ticketName,
      type: ChannelType.GuildText,
      parent: config.categories.supportTicket,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id,     allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        { id: config.roles.admin,      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        { id: config.roles.staff,      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
      ],
    });
  } catch (e) {
    return interaction.reply({ content: `${emojis.error} Failed to create ticket.`, ephemeral: true });
  }

  db.setTicket(channel.id, {
    channelId: channel.id,
    userId: interaction.user.id,
    type,
    status: 'open',
    createdAt: Date.now(),
  });

  const closeRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`close_ticket_${channel.id}`)
      .setLabel('Close Ticket')
      .setStyle(ButtonStyle.Danger),
  );

  await channel.send({
    content: `<@${interaction.user.id}> ${emojis.ticket} **${labels[type]}** ticket opened! Staff will be with you shortly.`,
    embeds: [{
      color: 0x3498db,
      title: `${emojis.ticket} ${labels[type]}`,
      description: `Please describe your issue in detail below. A staff member will assist you soon.\n\n${emojis.info} By continuing, you agree to our community rules.`,
      footer: { text: `${config.botName} • Support System` },
      timestamp: new Date().toISOString(),
    }],
    components: [closeRow],
  });

  await interaction.reply({ content: `${emojis.success} Ticket created: ${channel}`, ephemeral: true });
}

// ── Close Ticket ────────────────────────

async function handleCloseTicket(interaction) {
  const channelId = interaction.customId.replace('close_ticket_', '');
  const ticket    = db.getTicket(channelId);

  const isAdmin  = interaction.member.roles.cache.has(config.roles.admin);
  const isStaff  = interaction.member.roles.cache.has(config.roles.staff);
  const isOwner  = ticket && interaction.user.id === ticket.userId;

  if (!isAdmin && !isStaff && !isOwner && !config.ownerIds.includes(interaction.user.id)) {
    return interaction.reply({ content: `${emojis.error} You can't close this ticket.`, ephemeral: true });
  }

  if (ticket && ticket.status === 'active') {
    // Don't allow closing active exchange deals
    return interaction.reply({ content: `${emojis.error} Cannot close a ticket with an active deal. Resolve or dispute the deal first.`, ephemeral: true });
  }

  db.setTicket(channelId, { status: 'closed', closedAt: Date.now(), closedBy: interaction.user.id });

  await interaction.reply({ content: `${emojis.success} Ticket closing in 5 seconds...` });
  setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
}

// ── Restore Roles (Recovery) ────────────

async function handleRestoreRoles(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('recovery_modal')
    .setTitle('Role Recovery');

  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Your Recovery Token')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('DE-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX')
        .setRequired(true)
    )
  );

  await interaction.showModal(modal);
}

async function handleRecoveryModal(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const token  = interaction.fields.getTextInputValue('token');
  const result = await recovery.useRecoveryToken(interaction.user.id, token, interaction.guild, config);

  if (!result.success) {
    return interaction.editReply(`${emojis.error} Recovery failed: ${result.reason}`);
  }

  await interaction.editReply(
    `${emojis.success} Roles restored successfully! Your exchanger status has been transferred to this account.\n` +
    `${emojis.info} A new recovery token has been sent to your DMs.`
  );
}

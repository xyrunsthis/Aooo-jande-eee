// ─────────────────────────────────────────
//   DIVINE EXCHANGE — EXCHANGE PANEL
//   /panel exchange — posts the main panel
// ─────────────────────────────────────────
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const config = require('../config');
const emojis = require('../emojis');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('panel')
    .setDescription('Post a panel')
    .addStringOption(opt =>
      opt.setName('type')
        .setDescription('Which panel to post')
        .setRequired(true)
        .addChoices(
          { name: 'Exchange Panel', value: 'exchange' },
          { name: 'Support Panel',  value: 'support'  },
          { name: 'Recovery Panel', value: 'recovery' },
        )
    ),

  async execute(interaction) {
    const isOwner = config.ownerIds.includes(interaction.user.id);
    const isAdmin = interaction.member.roles.cache.has(config.roles.admin);
    if (!isOwner && !isAdmin) {
      return interaction.reply({ content: `${emojis.error} You don't have permission to use this.`, ephemeral: true });
    }

    const type = interaction.options.getString('type');

    if (type === 'exchange') await postExchangePanel(interaction);
    else if (type === 'support') await postSupportPanel(interaction);
    else if (type === 'recovery') await postRecoveryPanel(interaction);
  }
};

// ── Exchange Panel ───────────────────────

async function postExchangePanel(interaction) {
  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle(`${emojis.exchange} ${config.botName}`)
    .setDescription(`**Fast ${emojis.dot} Secure ${emojis.dot} Trusted Currency Exchanges**\n\n${emojis.arrow} Exchange Crypto, INR and other supported payment methods with trusted exchangers.\n\u200b`)
    .addFields(
      {
        name: `${emojis.star} Why ${config.botName}?`,
        value:
          `${emojis.dot} Fast Processing\n` +
          `${emojis.dot} Secure Transactions\n` +
          `${emojis.dot} Verified Exchangers\n` +
          `${emojis.dot} Competitive Rates\n` +
          `${emojis.dot} Trusted Community`,
      },
      {
        name: `\u200b`,
        value: `${emojis.info} **Ready To Exchange?**\nOpen a ticket below and one of our exchange specialists will assist you.`,
      }
    )
    .setFooter({ text: `${config.botName} • Secure Exchanges • Professional Support` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('start_exchange')
      .setLabel('Start Exchange')
      .setEmoji({ name: 'sparkle', id: '1000000000000000013', animated: true })
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('view_rates')
      .setLabel('View Rates')
      .setEmoji({ name: 'rates', id: '1000000000000000022', animated: true })
      .setStyle(ButtonStyle.Secondary),
  );

  await interaction.reply({ content: '✅ Panel posted!', ephemeral: true });
  await interaction.channel.send({ embeds: [embed], components: [row] });
}

// ── Support Panel ────────────────────────

async function postSupportPanel(interaction) {
  const { StringSelectMenuBuilder } = require('discord.js');

  const embed = new EmbedBuilder()
    .setColor(0xe74c3c)
    .setTitle(`${emojis.shield} ${config.botName} Support Panel`)
    .setDescription(`Our team is here to help. Response times may vary depending on our load, but we'll get to you as fast as we can!\n\u200b`)
    .addFields(
      { name: `${emojis.success} General Support`,      value: 'Questions, technical issues, and account assistance' },
      { name: `${emojis.staff} Staff Application`,      value: 'Apply to join the team' },
      { name: `${emojis.exchanger} Become an Exchanger`, value: 'Apply for exchanger verification' },
      { name: `${emojis.warning} Report Issues`,         value: 'Report abuse, fraud, or policy violations' },
      { name: `${emojis.recovery} Account Recovery`,     value: 'Recover access to your account' },
      { name: `${emojis.crown} Partnership Inquiries`,   value: 'Propose a business collaboration' },
      { name: `${emojis.star} Claim Rewards`,            value: 'Submit a reward claim' },
    )
    .addFields({ name: '\u200b', value: `${emojis.info} **Important Note:**\nBy opening a ticket, you're agreeing to our community rules. Please be respectful to our staff — they're here to help!` })
    .setFooter({ text: `${config.botName} • Support System` })
    .setTimestamp();

  const menu = new StringSelectMenuBuilder()
    .setCustomId('support_ticket_select')
    .setPlaceholder('Choose a ticket category...')
    .addOptions([
      { label: 'General Support',      description: 'Questions, technical issues, account assistance', value: 'general',     emoji: '✅' },
      { label: 'Staff Application',    description: 'Apply to join the team',                          value: 'staff_app',   emoji: '🛡️' },
      { label: 'Become an Exchanger',  description: 'Apply for exchanger verification',                value: 'exchanger_app', emoji: '🔄' },
      { label: 'Report Issues',        description: 'Report abuse, fraud, or policy violations',       value: 'report',      emoji: '🚨' },
      { label: 'Account Recovery',     description: 'Recover access to your account',                  value: 'recovery',    emoji: '✔️' },
      { label: 'Partnership Inquiries',description: 'Propose a business collaboration',                value: 'partnership', emoji: '🐸' },
      { label: 'Claim Rewards',        description: 'Submit a reward claim',                           value: 'rewards',     emoji: '🎁' },
    ]);

  const row = new ActionRowBuilder().addComponents(menu);

  await interaction.reply({ content: '✅ Support panel posted!', ephemeral: true });
  await interaction.channel.send({ embeds: [embed], components: [row] });
}

// ── Recovery Panel ───────────────────────

async function postRecoveryPanel(interaction) {
  // Staff only channel panel
  const isStaff = interaction.member.roles.cache.has(config.roles.staff) ||
                  interaction.member.roles.cache.has(config.roles.admin) ||
                  config.ownerIds.includes(interaction.user.id);
  if (!isStaff) {
    return interaction.reply({ content: `${emojis.error} This panel is for staff only.`, ephemeral: true });
  }

  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`${emojis.recovery} Role Restoration`)
    .setDescription(
      `Have you returned to the server and need your roles back?\n\u200b\n` +
      `${emojis.dot} Click the button below.\n` +
      `${emojis.dot} Enter your secure Recovery Token.\n` +
      `${emojis.dot} Your roles will be transferred from your old account to this one.\n\u200b`
    )
    .setFooter({ text: `${config.botName} • Recovery System` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('restore_roles')
      .setLabel('Restore Roles')
      .setEmoji({ name: '✅' })
      .setStyle(ButtonStyle.Success),
  );

  await interaction.reply({ content: '✅ Recovery panel posted!', ephemeral: true });
  await interaction.channel.send({ embeds: [embed], components: [row] });
}

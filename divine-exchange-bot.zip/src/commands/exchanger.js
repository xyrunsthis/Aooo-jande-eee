// ─────────────────────────────────────────
//   DIVINE EXCHANGE — EXCHANGER COMMANDS
//   Admin commands to manage exchangers
// ─────────────────────────────────────────
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config   = require('../config');
const emojis   = require('../emojis');
const db       = require('../utils/db');
const recovery = require('../utils/recovery');
const logger   = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('exchanger')
    .setDescription('Manage exchangers')
    .addSubcommand(sub => sub
      .setName('approve')
      .setDescription('Approve an exchanger application')
      .addUserOption(opt => opt.setName('user').setDescription('User to approve').setRequired(true))
      .addNumberOption(opt => opt.setName('collateral').setDescription('Collateral amount in USDT they deposited').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('reject')
      .setDescription('Reject an exchanger application')
      .addUserOption(opt => opt.setName('user').setDescription('User to reject').setRequired(true))
      .addStringOption(opt => opt.setName('reason').setDescription('Rejection reason').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('info')
      .setDescription('View exchanger info')
      .addUserOption(opt => opt.setName('user').setDescription('Exchanger to view').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('suspend')
      .setDescription('Suspend an exchanger')
      .addUserOption(opt => opt.setName('user').setDescription('Exchanger to suspend').setRequired(true))
      .addStringOption(opt => opt.setName('reason').setDescription('Reason').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('unsuspend')
      .setDescription('Unsuspend an exchanger')
      .addUserOption(opt => opt.setName('user').setDescription('Exchanger to unsuspend').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('cleartax')
      .setDescription('Mark tax as paid and remove Tax Due restriction')
      .addUserOption(opt => opt.setName('user').setDescription('Exchanger').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription('List all active exchangers')
    ),

  async execute(interaction) {
    const isOwner = config.ownerIds.includes(interaction.user.id);
    const isAdmin = interaction.member.roles.cache.has(config.roles.admin);
    if (!isOwner && !isAdmin) {
      return interaction.reply({ content: `${emojis.error} No permission.`, ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'approve')    return approveExchanger(interaction);
    if (sub === 'reject')     return rejectExchanger(interaction);
    if (sub === 'info')       return exchangerInfo(interaction);
    if (sub === 'suspend')    return suspendExchanger(interaction);
    if (sub === 'unsuspend')  return unsuspendExchanger(interaction);
    if (sub === 'cleartax')   return clearTax(interaction);
    if (sub === 'list')       return listExchangers(interaction);
  }
};

async function approveExchanger(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const user       = interaction.options.getUser('user');
  const collateral = interaction.options.getNumber('collateral');
  const dealLimit  = collateral; // 1:1 collateral = deal limit

  if (collateral < config.minCollateral) {
    return interaction.editReply(`${emojis.error} Minimum collateral is $${config.minCollateral} USDT.`);
  }

  db.setExchanger(user.id, {
    userId:       user.id,
    collateral,
    dealLimit,
    collateralUsed: 0,
    status:       'active',
    verified:     true,
    activeDeal:   null,
    totalDeals:   0,
    totalVolume:  0,
    totalFees:    0,
    pendingTax:   0,
    joinedAt:     Date.now(),
    approvedBy:   interaction.user.id,
  });

  // Assign exchanger role
  const member = await interaction.guild.members.fetch(user.id);
  await member.roles.add(config.roles.exchanger);
  await member.roles.add(config.roles.verifiedExchanger);

  // Issue recovery token
  await recovery.issueRecoveryToken(user.id, interaction.client);

  // Log it
  await logger.logExchangerApproved(interaction.client, { userId: user.id, collateral, dealLimit });

  // DM the user
  try {
    await user.send({
      embeds: [{
        color: 0x2ecc71,
        title: `${emojis.verified} Application Approved!`,
        description:
          `Congratulations! Your exchanger application on **${config.botName}** has been approved.\n\n` +
          `${emojis.collateral} **Collateral:** $${collateral} USDT\n` +
          `${emojis.limit} **Deal Limit:** $${dealLimit} USDT per deal\n` +
          `${emojis.fee} **Fee:** ${config.dealFeePercent}% per completed deal\n\n` +
          `${emojis.info} Your recovery token has been sent separately. Keep it safe!`,
        footer: { text: `${config.botName} • Exchanger System` },
        timestamp: new Date().toISOString(),
      }]
    });
  } catch (_) {}

  await interaction.editReply(`${emojis.success} Approved **${user.tag}** as an Exchanger with $${collateral} USDT collateral.`);
}

async function rejectExchanger(interaction) {
  const user   = interaction.options.getUser('user');
  const reason = interaction.options.getString('reason');

  try {
    await user.send({
      embeds: [{
        color: 0xe74c3c,
        title: `${emojis.rejected} Application Rejected`,
        description: `Your exchanger application on **${config.botName}** has been rejected.\n\n**Reason:** ${reason}`,
        footer: { text: `${config.botName} • Exchanger System` },
        timestamp: new Date().toISOString(),
      }]
    });
  } catch (_) {}

  await interaction.reply({ content: `${emojis.success} Rejected **${user.tag}**'s application.`, ephemeral: true });
}

async function exchangerInfo(interaction) {
  const user = interaction.options.getUser('user');
  const data = db.getExchanger(user.id);

  if (!data) {
    return interaction.reply({ content: `${emojis.error} No exchanger data found for ${user.tag}.`, ephemeral: true });
  }

  const embed = new EmbedBuilder()
    .setColor(data.status === 'active' ? 0x2ecc71 : 0xe74c3c)
    .setTitle(`${emojis.exchanger} Exchanger Info — ${user.tag}`)
    .setThumbnail(user.displayAvatarURL())
    .addFields(
      { name: `${emojis.shield} Status`,       value: data.status,                           inline: true },
      { name: `${emojis.collateral} Collateral`, value: `$${data.collateral} USDT`,           inline: true },
      { name: `${emojis.limit} Deal Limit`,    value: `$${data.dealLimit} USDT`,             inline: true },
      { name: `${emojis.deal} Total Deals`,    value: `${data.totalDeals}`,                  inline: true },
      { name: `${emojis.usdt} Total Volume`,   value: `$${data.totalVolume} USDT`,           inline: true },
      { name: `${emojis.tax} Pending Tax`,     value: `$${data.pendingTax?.toFixed(4) || 0} USDT`, inline: true },
      { name: `${emojis.active} Active Deal`,  value: data.activeDeal || 'None',             inline: true },
      { name: `${emojis.verified} Verified`,   value: data.verified ? 'Yes' : 'No',          inline: true },
    )
    .setFooter({ text: `${config.botName} • Exchanger System` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function suspendExchanger(interaction) {
  const user   = interaction.options.getUser('user');
  const reason = interaction.options.getString('reason');
  db.setExchanger(user.id, { status: 'suspended', suspendReason: reason, suspendedBy: interaction.user.id, suspendedAt: Date.now() });

  const member = await interaction.guild.members.fetch(user.id).catch(() => null);
  if (member) await member.roles.remove(config.roles.exchanger).catch(() => null);

  try {
    await user.send({
      embeds: [{
        color: 0xe74c3c,
        title: `${emojis.ban} Exchanger Suspended`,
        description: `Your exchanger status on **${config.botName}** has been suspended.\n\n**Reason:** ${reason}`,
        footer: { text: `${config.botName} • Exchanger System` },
        timestamp: new Date().toISOString(),
      }]
    });
  } catch (_) {}

  await interaction.reply({ content: `${emojis.success} **${user.tag}** has been suspended.`, ephemeral: true });
}

async function unsuspendExchanger(interaction) {
  const user = interaction.options.getUser('user');
  db.setExchanger(user.id, { status: 'active', suspendReason: null });

  const member = await interaction.guild.members.fetch(user.id).catch(() => null);
  if (member) await member.roles.add(config.roles.exchanger).catch(() => null);

  await interaction.reply({ content: `${emojis.success} **${user.tag}** has been unsuspended.`, ephemeral: true });
}

async function clearTax(interaction) {
  const user = interaction.options.getUser('user');
  const data = db.getExchanger(user.id);
  if (!data) return interaction.reply({ content: `${emojis.error} Not an exchanger.`, ephemeral: true });

  db.setExchanger(user.id, { pendingTax: 0, taxDue: false });

  const member = await interaction.guild.members.fetch(user.id).catch(() => null);
  if (member) await member.roles.remove(config.roles.taxDue).catch(() => null);

  await interaction.reply({ content: `${emojis.success} Tax cleared for **${user.tag}**. Tax Due role removed.`, ephemeral: true });
}

async function listExchangers(interaction) {
  const all = db.getAllExchangers();
  const list = Object.values(all).filter(e => e.status === 'active');

  if (!list.length) return interaction.reply({ content: `${emojis.info} No active exchangers.`, ephemeral: true });

  const lines = list.map(e => `${emojis.dot} <@${e.userId}> — Limit: $${e.dealLimit} USDT | Deals: ${e.totalDeals} | Tax Pending: $${e.pendingTax?.toFixed(2) || 0}`);

  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`${emojis.exchanger} Active Exchangers (${list.length})`)
    .setDescription(lines.join('\n'))
    .setFooter({ text: `${config.botName} • Exchanger System` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

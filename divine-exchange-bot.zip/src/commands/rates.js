// ─────────────────────────────────────────
//   DIVINE EXCHANGE — RATES COMMAND
// ─────────────────────────────────────────
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');
const emojis = require('../emojis');
const { getRates } = require('../utils/rates');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rates')
    .setDescription('View current exchange rates'),

  async execute(interaction) {
    await interaction.deferReply();
    const rates = await getRates();

    const usdtInr = rates.usdtInr ? `₹${rates.usdtInr.toLocaleString('en-IN')}` : 'Unavailable';
    const updated = rates.updatedAt ? `<t:${Math.floor(rates.updatedAt / 1000)}:R>` : 'Unknown';

    const embed = new EmbedBuilder()
      .setColor(0xf39c12)
      .setTitle(`${emojis.rates} Live Exchange Rates`)
      .setDescription(`Rates are updated every ${config.ratesRefreshMinutes} minutes.\n\u200b`)
      .addFields(
        { name: `${emojis.usdt} USDT → INR`,  value: `**1 USDT = ${usdtInr}**`, inline: true },
        { name: `${emojis.inr}  INR → USDT`,  value: `**₹1 = ${rates.usdtInr ? (1 / rates.usdtInr).toFixed(6) + ' USDT' : 'N/A'}**`, inline: true },
        { name: '\u200b', value: '\u200b', inline: false },
        { name: `${emojis.fee} Platform Fee`,  value: `${config.dealFeePercent}% per deal (paid by Exchanger)`, inline: true },
        { name: `${emojis.wallet} Wallet`,     value: `USDT (Polygon Network)`, inline: true },
      )
      .addFields({ name: `${emojis.info} Supported Pairs`, value: `${emojis.dot} Crypto → INR\n${emojis.dot} INR → Crypto\n${emojis.dot} Crypto → Crypto` })
      .setFooter({ text: `${config.botName} • Last updated ${rates.updatedAt ? new Date(rates.updatedAt).toLocaleTimeString() : 'N/A'}` })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
};

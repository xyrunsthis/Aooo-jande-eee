// ─────────────────────────────────────────
//   DIVINE EXCHANGE — MEMBER LEAVE EVENT
//   Revokes recovery token when exchanger leaves
// ─────────────────────────────────────────
const config   = require('../config');
const db       = require('../utils/db');
const recovery = require('../utils/recovery');
const logger   = require('../utils/logger');

module.exports = async (member) => {
  const exchangerData = db.getExchanger(member.id);
  if (!exchangerData) return;

  // Revoke their recovery token
  recovery.revokeToken(member.id);

  // If they had an active deal, mark it as abandoned
  if (exchangerData.activeDeal) {
    db.setDeal(exchangerData.activeDeal, {
      status: 'abandoned',
      abandonedAt: Date.now(),
      reason: 'Exchanger left the server',
    });

    // Find the ticket and notify
    const allTickets = db.getAllTickets();
    const entry = Object.entries(allTickets).find(([, t]) => t.dealId === exchangerData.activeDeal);
    if (entry) {
      const [channelId, ticket] = entry;
      db.setTicket(channelId, { status: 'abandoned', exchangerId: null });
      try {
        const channel = await member.client.channels.fetch(channelId);
        if (channel) {
          await channel.send({
            embeds: [{
              color: 0xe74c3c,
              title: `⚠️ Exchanger Left`,
              description: `The exchanger assigned to this deal has left the server. An admin will review this shortly.\n\nIf you were scammed, the exchanger's collateral of **$${exchangerData.collateral} USDT** is recoverable.`,
              footer: { text: `${config.botName} • Deal Protection` },
              timestamp: new Date().toISOString(),
            }]
          });
        }
      } catch (_) {}
    }
  }

  // Mark exchanger as inactive
  db.setExchanger(member.id, {
    status: 'left',
    leftAt: Date.now(),
    activeDeal: null,
  });

  await logger.logExchangerLeft(member.client, { userId: member.id });
};

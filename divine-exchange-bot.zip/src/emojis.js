// ─────────────────────────────────────────
//   DIVINE EXCHANGE — EMOJIS CONFIG
//   Replace the right side values with your
//   custom Discord emoji IDs from your server
// ─────────────────────────────────────────

module.exports = {
  // ── General ──────────────────────────────
  success:      '<a:de_success:1000000000000000001>',
  error:        '<a:de_error:1000000000000000002>',
  loading:      '<a:de_loading:1000000000000000003>',
  warning:      '<:de_warning:1000000000000000004>',
  info:         '<:de_info:1000000000000000005>',
  crown:        '<:de_crown:1000000000000000006>',
  shield:       '<:de_shield:1000000000000000007>',
  lock:         '<:de_lock:1000000000000000008>',
  unlock:       '<:de_unlock:1000000000000000009>',
  star:         '<a:de_star:1000000000000000010>',
  fire:         '<a:de_fire:1000000000000000011>',
  rocket:       '<a:de_rocket:1520341355811967008>',
  sparkle:      '<a:de_sparkle:1000000000000000013>',
  arrow:        '<:de_arrow:1000000000000000014>',
  dot:          '<:de_dot:1000000000000000015>',
  divider:      '<:de_divider:1000000000000000016>',

  // ── Exchange ─────────────────────────────
  exchange:     '<a:de_exchange:1000000000000000017>',
  crypto:       '<:de_crypto:1000000000000000018>',
  usdt:         '<:de_usdt:1000000000000000019>',
  inr:          '<:de_inr:1000000000000000020>',
  wallet:       '<:de_wallet:1000000000000000021>',
  rates:        '<a:de_rates:1000000000000000022>',
  ticket:       '<:de_ticket:1000000000000000023>',
  deal:         '<:de_deal:1000000000000000024>',
  complete:     '<a:de_complete:1000000000000000025>',
  cancel:       '<:de_cancel:1000000000000000026>',

  // ── Exchanger ────────────────────────────
  exchanger:    '<:de_exchanger:1000000000000000027>',
  collateral:   '<:de_collateral:1000000000000000028>',
  verified:     '<a:de_verified:1000000000000000029>',
  tax:          '<:de_tax:1000000000000000030>',
  taxdue:       '<:de_taxdue:1000000000000000031>',
  fee:          '<:de_fee:1000000000000000032>',
  limit:        '<:de_limit:1000000000000000033>',
  token:        '<a:de_token:1000000000000000034>',

  // ── Staff / Admin ────────────────────────
  admin:        '<:de_admin:1000000000000000035>',
  staff:        '<:de_staff:1000000000000000036>',
  ban:          '<:de_ban:1000000000000000037>',
  unban:        '<:de_unban:1000000000000000038>',
  log:          '<:de_log:1000000000000000039>',
  recovery:     '<:de_recovery:1000000000000000040>',

  // ── Status ────────────────────────────────
  pending:      '<a:de_pending:1000000000000000041>',
  active:       '<a:de_active:1000000000000000042>',
  closed:       '<:de_closed:1000000000000000043>',
  disputed:     '<a:de_disputed:1000000000000000044>',
  approved:     '<a:de_approved:1000000000000000045>',
  rejected:     '<:de_rejected:1000000000000000046>',

  // ── Payment ───────────────────────────────
  upi:          '<:de_upi:1000000000000000047>',
  screenshot:   '<:de_screenshot:1000000000000000048>',
  proof:        '<:de_proof:1000000000000000049>',
  paid:         '<a:de_paid:1000000000000000050>',
};

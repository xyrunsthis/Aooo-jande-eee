// ─────────────────────────────────────────
//   DIVINE EXCHANGE — CENTRAL CONFIG
//   All values pulled from .env
// ─────────────────────────────────────────
require('dotenv').config();

module.exports = {
  // ── Bot ──────────────────────────────────
  token:          process.env.BOT_TOKEN,
  botName:        process.env.BOT_NAME || 'Divine Exchange',
  prefix:         process.env.BOT_PREFIX || '/',
  clientId:       process.env.CLIENT_ID,
  guildId:        process.env.GUILD_ID,
  developerId:    process.env.DEVELOPER_ID,

  // ── Owners ───────────────────────────────
  ownerIds: (process.env.OWNER_IDS || '').split(',').map(id => id.trim()).filter(Boolean),

  // ── Channels ─────────────────────────────
  channels: {
    exchangePanel:    process.env.EXCHANGE_PANEL_CHANNEL,
    supportPanel:     process.env.SUPPORT_PANEL_CHANNEL,
    rates:            process.env.RATES_CHANNEL,
    history:          process.env.HISTORY_CHANNEL,
    vouches:          process.env.VOUCHES_CHANNEL,
    log:              process.env.LOG_CHANNEL,
    exchangerLog:     process.env.EXCHANGER_LOG_CHANNEL,
    taxLog:           process.env.TAX_LOG_CHANNEL,
  },

  // ── Categories ───────────────────────────
  categories: {
    exchangeTicket:   process.env.EXCHANGE_TICKET_CATEGORY,
    supportTicket:    process.env.SUPPORT_TICKET_CATEGORY,
    exchangerApp:     process.env.EXCHANGER_APP_CATEGORY,
  },

  // ── Roles ────────────────────────────────
  roles: {
    admin:            process.env.ADMIN_ROLE,
    exchanger:        process.env.EXCHANGER_ROLE,
    verifiedExchanger: process.env.VERIFIED_EXCHANGER_ROLE,
    staff:            process.env.STAFF_ROLE,
    taxDue:           process.env.TAX_DUE_ROLE,
    customer:         process.env.CUSTOMER_ROLE,
  },

  // ── Wallet ───────────────────────────────
  ownerWallet:        process.env.OWNER_WALLET,

  // ── Fee & Collateral ─────────────────────
  dealFeePercent:     parseFloat(process.env.DEAL_FEE_PERCENT) || 1,
  collateralMultiplier: parseFloat(process.env.COLLATERAL_MULTIPLIER) || 2,
  minCollateral:      parseFloat(process.env.MIN_COLLATERAL) || 5,

  // ── Rates ────────────────────────────────
  ratesRefreshMinutes: parseInt(process.env.RATES_REFRESH_MINUTES) || 5,
};

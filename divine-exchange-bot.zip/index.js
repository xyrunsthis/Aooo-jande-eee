// ─────────────────────────────────────────
//   DIVINE EXCHANGE — MAIN ENTRY POINT
// ─────────────────────────────────────────
require('dotenv').config();

const { Client, GatewayIntentBits, Partials, Collection, REST, Routes } = require('discord.js');
const fs     = require('fs');
const path   = require('path');
const config = require('./src/config');

// ── Client Setup ─────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

client.commands = new Collection();

// ── Load Commands ─────────────────────────
const commandsPath = path.join(__dirname, 'src/commands');
const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));
const commandsData = [];

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
  commandsData.push(command.data.toJSON());
  console.log(`[Commands] Loaded: ${command.data.name}`);
}

// ── Events ────────────────────────────────
client.once('ready', async () => {
  console.log(`\n✅ ${config.botName} is online as ${client.user.tag}`);
  console.log(`📡 Serving guild: ${config.guildId}`);

  // Register slash commands
  try {
    const rest = new REST({ version: '10' }).setToken(config.token);
    await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: commandsData });
    console.log(`⚡ Slash commands registered (${commandsData.length})`);
  } catch (e) {
    console.error('[Commands] Failed to register:', e.message);
  }

  // Start rates refresh loop
  const { refreshRates } = require('./src/utils/rates');
  await refreshRates();
  setInterval(refreshRates, config.ratesRefreshMinutes * 60 * 1000);
  console.log(`💹 Rates refreshing every ${config.ratesRefreshMinutes} minutes`);
});

// ── Interaction Handler ───────────────────
const interactionHandler = require('./src/handlers/interactions');

client.on('interactionCreate', async (interaction) => {
  // Slash commands
  if (interaction.isChatInputCommand()) {
    const command = client.commands.get(interaction.commandName);
    if (!command) return;
    try {
      await command.execute(interaction);
    } catch (e) {
      console.error(`[Command Error] ${interaction.commandName}:`, e);
      const reply = { content: '❌ An error occurred.', ephemeral: true };
      if (interaction.replied || interaction.deferred) await interaction.followUp(reply);
      else await interaction.reply(reply);
    }
    return;
  }

  // Buttons, Select Menus, Modals
  try {
    await interactionHandler(interaction);
  } catch (e) {
    console.error('[Interaction Error]:', e);
    try {
      const reply = { content: '❌ An error occurred.', ephemeral: true };
      if (interaction.replied || interaction.deferred) await interaction.followUp(reply);
      else await interaction.reply(reply);
    } catch (_) {}
  }
});

// ── Member Leave ──────────────────────────
const memberLeaveHandler = require('./src/events/guildMemberRemove');
client.on('guildMemberRemove', memberLeaveHandler);

// ── Error Handling ────────────────────────
client.on('error', e => console.error('[Client Error]:', e));
process.on('unhandledRejection', e => console.error('[Unhandled Rejection]:', e));

// ── Login ─────────────────────────────────
client.login(config.token).catch(e => {
  console.error('[Login Failed]:', e.message);
  process.exit(1);
});

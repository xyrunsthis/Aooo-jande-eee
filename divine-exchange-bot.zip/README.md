# Divine Exchange Bot

A secure Discord crypto exchange bot with collateral-based anti-scam protection.

---

## Features

- Exchange ticket system (Crypto→INR, INR→Crypto, Crypto→Crypto)
- Exchanger collateral system (deal limit = collateral amount)
- One deal at a time per exchanger
- Anti-scam: client split-screen screenshot proof required
- 1% fee system with tax due enforcement
- Recovery token system for exchanger role restoration
- Admin dispute resolution
- Live USDT/INR rates via CoinGecko
- Full transaction logging
- Everything configurable from `.env`

---

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
```
Edit `.env` with your values:
- `BOT_TOKEN` — your bot token from Discord Developer Portal
- `CLIENT_ID` — your bot's application ID
- `GUILD_ID` — your server ID
- `OWNER_IDS` — up to 5 owner Discord IDs (comma separated)
- All channel, category, and role IDs

### 3. Create required Discord structure

**Categories:**
- Exchange Tickets (for exchange deal channels)
- Support Tickets (for support ticket channels)
- Exchanger Applications

**Channels:**
- `#exchange` — post the exchange panel here
- `#support` — post the support panel here
- `#recovery` — post the recovery panel here (staff only)
- `#rates` — rates channel
- `#history` — deal history log
- `#vouches` — vouch channel
- Log channels as configured

**Roles:**
- `Admin` — full bot control
- `Exchanger` — verified exchangers
- `Verified Exchanger` — approved exchangers
- `Staff` — support staff
- `Tax Due` — auto-assigned when fee is owed
- `Customer` — regular users

### 4. Start the bot
```bash
npm start
```

---

## Commands

| Command | Description | Permission |
|---------|-------------|------------|
| `/panel exchange` | Post the exchange panel | Admin/Owner |
| `/panel support` | Post the support panel | Admin/Owner |
| `/panel recovery` | Post the recovery panel | Admin/Owner |
| `/rates` | View live rates | Everyone |
| `/exchanger approve` | Approve an exchanger | Admin/Owner |
| `/exchanger reject` | Reject an application | Admin/Owner |
| `/exchanger info` | View exchanger details | Admin/Owner |
| `/exchanger suspend` | Suspend an exchanger | Admin/Owner |
| `/exchanger unsuspend` | Unsuspend an exchanger | Admin/Owner |
| `/exchanger cleartax` | Clear tax due & remove role | Admin/Owner |
| `/exchanger list` | List all active exchangers | Admin/Owner |

---

## How It Works

### For Clients
1. Click **Start Exchange** in the exchange panel
2. Select exchange type (Crypto→INR, INR→Crypto, Crypto→Crypto)
3. Enter amount, UPI/wallet, notes
4. Wait for an Exchanger to claim your ticket
5. Complete the exchange with the Exchanger
6. Upload split-screen screenshot (UPI payment + Discord open simultaneously)
7. Confirm deal complete

### For Exchangers
1. Apply via Support Panel → "Become an Exchanger"
2. Deposit collateral to owner's USDT (Polygon) wallet
3. Admin approves → you receive Exchanger role + Recovery Token (DM)
4. Claim available deals (within your deal limit)
5. Complete one deal at a time
6. After each deal: pay 1% fee to owner wallet → click "Tax Paid" → Admin clears restriction

### Anti-Scam Protection
- Exchanger's collateral = their deal limit (e.g. $20 collateral = max $20 deals)
- If exchanger scams: admin can return collateral to client
- Exchanger cannot claim deals above their limit
- Exchanger cannot claim new deals while Tax Due role is active
- Recovery token revoked if exchanger leaves server
- All deals logged permanently

---

## Custom Emojis

Edit `src/emojis.js` and replace the right-hand values with your server's custom emoji IDs:
```js
rocket: '<a:rocket:1520341355811967008>'
```

---

## Developer
<@652821303296000021>
